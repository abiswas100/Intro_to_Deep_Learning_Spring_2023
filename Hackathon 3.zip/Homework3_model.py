#matplotlib inline
from __future__ import print_function
import numpy as np
import tensorflow as tf
import tensorflow_datasets as tfds
import matplotlib.pyplot as plt
from tqdm import tqdm

DATA_DIR = './tensorflow-datasets/'

(ds_train, ds_test), ds_info = tfds.load('mnist',split=['train[:90%]', 'test[10%:]'],shuffle_files=True,as_supervised=True,with_info=True,)

train_ds = ds_train.shuffle(1024).batch(32)
val_ds = ds_test.shuffle(1024).batch(32)

# Define the first model
hw3model = tf.keras.Sequential([
    tf.keras.layers.Flatten(input_shape=(28, 28, 1)),
    tf.keras.layers.Dense(64, activation='relu'),
    tf.keras.layers.Dense(100, activation='relu'),
    tf.keras.layers.Dense(10, activation='relu')
])

# Compile the first model
hw3model.compile(optimizer='RMSprop', loss='sparse_categorical_crossentropy', metrics=['accuracy'])

# Add early stopping to the first model
model_early_stop = tf.keras.callbacks.EarlyStopping(monitor='val_loss', patience=3)


# # Train the first model
model_train = hw3model.fit(train_ds, epochs=5, validation_data=val_ds)

optimizer = tf.keras.optimizers.RMSprop()
# add model check point
checkpoint = tf.train.Checkpoint(model=hw3model, optimizer=optimizer)

# Save a checkpoint to /tmp/training_checkpoints-{save_counter}. Every time
# checkpoint.save is called, the save counter is increased.
save_dir = checkpoint.save('/tmp/training_checkpoints')

# Restore the checkpointed values to the `model` object.
print("The save path is", save_dir)

print(hw3model.summary())
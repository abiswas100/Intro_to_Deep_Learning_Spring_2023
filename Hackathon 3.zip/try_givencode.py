# We'll start with our library imports...
from __future__ import print_function

import numpy as np                 # to use numpy arrays
import tensorflow as tf            # to specify and run computation graphs
import tensorflow_datasets as tfds # to load training data
import matplotlib.pyplot as plt    # to visualize data and draw plots
# from tqdm import tqdm              # to track progress of loops

DATA_DIR = './tensorflow-datasets/'


class Dense(tf.Module):
    def __init__(self, output_size, activation=tf.nn.relu, name=None):
        super(Dense, self).__init__(name=name) # remember this call to initialize the superclass
        self.output_size = output_size
        self.activation = activation
        self.is_built = False

    def build(self, x):
        input_dim = x.shape[-1]
        self.w = tf.Variable(
          tf.random.normal([input_dim, self.output_size]), name='w')
        self.b = tf.Variable(tf.zeros([self.output_size]), name='b')
        self.is_built = True

    @tf.function
    def __call__(self, x):
        if not self.is_built:
            self.build(x)
        y = tf.matmul(x, self.w) + self.b
        return self.activation(y)

# Create an instance of the layer
dense_layer = Dense(10)
# Call the model by passing the input to it
dense_layer(tf.ones([32,3]))
# We can get the variables of a Module for used calculating and applying gradients with `.trainable_variables`
dense_layer.trainable_variables


dense_layer = Dense(10)
optimizer = tf.keras.optimizers.Adam()
checkpoint = tf.train.Checkpoint(model=dense_layer, optimizer=optimizer)

# Save a checkpoint to /tmp/training_checkpoints-{save_counter}. Every time
# checkpoint.save is called, the save counter is increased.
save_dir = checkpoint.save('/tmp/training_checkpoints')

# Restore the checkpointed values to the `model` object.
print("The save path is", save_dir)
# status = checkpoint.restore(save_dir)
# # we can check that everything loaded correctly, this is silent if all is well
# status.assert_consumed()
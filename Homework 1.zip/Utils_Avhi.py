" Helper functions (e.g., for loading the data, small repetitive functions)"
'''
    Creator - Avhishek Biswas
'''
import os

import matplotlib.pyplot as plt  # to visualize data and draw plots
import numpy as np  # to use numpy arrays
import tensorflow as tf  # to specify and run computation graphs
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.datasets import cifar100
from tensorflow.keras.layers import *
from tensorflow.keras.models import Model, Sequential
from tensorflow.keras.regularizers import l1, l2
from tensorflow.keras.utils import to_categorical

os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"

print("import utils works")


def Import_Data_Avhi():
    # Performing Training and Testing Split After Loading Data
    (X_train, Y_train), (X_test, Y_test) = cifar100.load_data()

    # Performing Validation Split 
    X_train, X_val, Y_train, Y_val = train_test_split(X_train, Y_train, test_size=0.1, random_state=42)
    print("Trainng Data Shape",X_train.shape,"Training Feature Data Shape", Y_train.shape, "\n Validation Data Shape", X_val.shape, "Validation Feature Data Shape",Y_val.shape, "\n Testing Data Shape",X_test.shape, "Testing Data Shape",Y_test.shape)

    # Normalize the pixel values
    X_train = X_train.astype('float32') / 255.0
    X_test = X_test.astype('float32') / 255.0
    X_val = X_val.astype('float32') / 255.0

    # One-hot encode the labels
    num_classes = 100
    Y_train = to_categorical(Y_train, num_classes)
    Y_test = to_categorical(Y_test, num_classes)
    Y_val = to_categorical(Y_val, num_classes)

    # Flatten the labels to a 1D array
    Y_train = np.argmax(Y_train, axis=1)
    Y_test = np.argmax(Y_test, axis=1)
    Y_val = np.argmax(Y_val, axis=1)
    
    return X_train, Y_train, X_val, Y_val, X_test, Y_test


def plot_training_validation_accuracy(history):    
    # plot training and validation accuracy vs epochs
    plt.plot(history.history["accuracy"])
    plt.plot(history.history["val_accuracy"])
    plt.title("Model accuracy")
    plt.ylabel("Accuracy")
    plt.xlabel("Epoch")
    plt.legend(["Train", "Validation"], loc="upper left")

    # save plot as png file
    plt.savefig("accuracy_plot_model2.png")
    
def plot_training_validation_loss(history):
    # plot training and validation Loss vs epochs
    plt.plot(history.history["loss"])
    plt.plot(history.history["val_loss"])
    plt.title("Model Loss")
    plt.ylabel("Loss")
    plt.xlabel("Epoch")
    plt.legend(["Train", "Validation"], loc="upper left")

    # save plot as png file
    plt.savefig("loss_plot_model2.png")
    
    

# CONFUSION MATRIX
def plot_confusion_matrix(cm, classes,normalize= True,title='Confusion matrix', cmap = plt.cm.Reds):
    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()
    
    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        plt.tight_layout()
        plt.ylabel('Observation')
        plt.xlabel('Prediction')
    plt.savefig('confusion_matrix.png', format='png')
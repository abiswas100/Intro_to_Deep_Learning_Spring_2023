"Code that runs the main loop of training the TensorFlow models"
'''
    Creator - Avhishek Biswas
'''

import os

import matplotlib.pyplot as plt  # to visualize data and draw plots
import numpy as np  # to use numpy arrays
import tensorflow as tf  # to specify and run computation graphs
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.datasets import cifar100
from tensorflow.keras.layers import *
from tensorflow.keras.models import Model, Sequential
from tensorflow.keras.regularizers import l1, l2
from tensorflow.keras.utils import to_categorical

os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"

# Load the other files
import model_Avhi as model_A

import Utils_Avhi as Util_A


# Get the Data for Model 2
X_train_model2, Y_train_model2, X_val_model2, Y_val_model2, X_test_model2, Y_test_model2 = Util_A.Import_Data_Avhi()

# Get the Model 2
model2 = model_A.Avhi_model()

# Compile the Model 
model2_opt = 'Adam'
model2.compile(loss='sparse_categorical_crossentropy',optimizer = model2_opt,metrics=['accuracy'])

# Define early stopping criteria
model2_early_stop = EarlyStopping(monitor="val_accuracy", patience=10, mode="max", verbose=1)

# Fit the model on the data
model2_history = model2.fit(X_train_model2, Y_train_model2, epochs=50, validation_data=(X_val_model2, Y_val_model2), callbacks=[model2_early_stop])
model2_histories = model2_history.history["accuracy"]
print("\n Final Training Accuracy = ",model2_histories[-1])

# Model testing
model2_test_loss,model2_test_acc = model2.evaluate(X_test_model2, Y_test_model2)

print("\n Model 2 Testing accuracy", model2_test_acc)


# Plot Accuracy and Loss Curves
Util_A.plot_training_validation_accuracy(model2_history)
# Util_A.plot_training_validation_loss(model2_history)

# Plot Confusion Matrix
Y_pred_model2 = model2.predict(X_test_model2)
# Convert predictions classes to one hot encoders
Y_pred_classes_model2 = np.argmax(Y_pred_model2, axis = 1)
confusion_mtx = confusion_matrix(Y_test_model2, Y_pred_classes_model2)

# Plot the confusion matrix
Util_A.plot_confusion_matrix(confusion_mtx, classes = range(100))
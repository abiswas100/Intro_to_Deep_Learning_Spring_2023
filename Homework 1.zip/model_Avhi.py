"TensorFlow code that defines the network"
'''
    Creator - Avhishek Biswas
'''
import os

import matplotlib.pyplot as plt  # to visualize data and draw plots
import numpy as np  # to use numpy arrays
import tensorflow as tf  # to specify and run computation graphs
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.datasets import cifar100
from tensorflow.keras.layers import *
from tensorflow.keras.models import Model, Sequential
from tensorflow.keras.regularizers import l1, l2
from tensorflow.keras.utils import to_categorical


os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"

print("import model works")
    
def Avhi_model():
    # With Just Batch Normalization and L2 Regularization
    model = Sequential()

    model.add(Conv2D(input_shape=(32, 32, 3),kernel_size=(2, 2),padding="same",strides=(2, 2),filters=32,kernel_regularizer=l2(0.001)))#,kernel_regularizer=l2(0.001)
    model.add(BatchNormalization())
    model.add(Activation("relu"))
    model.add(MaxPooling2D(pool_size=(2, 2), strides=(1, 1), padding="same"))
    # model.add(Dropout(0.1))

    model.add(Conv2D(kernel_size=(2, 2), padding="same", strides=(2, 2), filters=64))
    model.add(BatchNormalization())
    model.add(Activation("relu"))
    model.add(MaxPooling2D(pool_size=(2, 2), strides=(1, 1), padding="same"))

    model.add(Conv2D(kernel_size=(2, 2), padding="same", strides=(2, 2), filters=128))
    model.add(BatchNormalization())
    model.add(Activation("relu"))
    model.add(MaxPooling2D(pool_size=(2, 2), strides=(1, 1), padding="same"))


    model.add(Conv2D(kernel_size=(2, 2), padding="same", strides=(2, 2), filters=256))
    model.add(BatchNormalization())
    model.add(Activation("relu"))
    model.add(MaxPooling2D(pool_size=(2, 2), strides=(1, 1), padding="same"))
    # model.add(Dropout(0.1))

    model.add(Conv2D(kernel_size=(2, 2), padding="same", strides=(2, 2), filters=512))
    model.add(BatchNormalization())
    model.add(Activation("relu"))
    model.add(MaxPooling2D(pool_size=(2, 2), strides=(1, 1), padding="same"))

    model.add(Conv2D(kernel_size=(2, 2), padding="same", strides=(2, 2), filters=1024))
    model.add(BatchNormalization())
    model.add(Activation("relu"))
    model.add(MaxPooling2D(pool_size=(2, 2), strides=(1, 1), padding="same"))

    model.add(Flatten())
    model.add(Dense(256))
    model.add(BatchNormalization())
    model.add(Activation("relu"))

    model.add(Dense(128))
    model.add(BatchNormalization())
    model.add(Activation("relu"))

    model.add(Dense(100, activation="softmax"))
    
    model.summary()
    
    return model


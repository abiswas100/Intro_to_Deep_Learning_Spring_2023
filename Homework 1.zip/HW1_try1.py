import os

import matplotlib.pyplot as plt  # to visualize data and draw plots
import numpy as np  # to use numpy arrays
import tensorflow as tf  # to specify and run computation graphs
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.datasets import cifar100
from tensorflow.keras.layers import *
from tensorflow.keras.models import Model, Sequential
from tensorflow.keras.regularizers import l1, l2
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.utils import plot_model

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3' 

# Performing Training and Testing Split After Loading Data
(X_train, Y_train), (X_test, Y_test) = cifar100.load_data()

print(X_train.shape, Y_train.shape, )

# Performing Validation Split 
X_train, X_val, Y_train, Y_val = train_test_split(X_train, Y_train, test_size=0.1, random_state=42)
print("Trainng Data Shape",X_train.shape,"Training Feature Data Shape", Y_train.shape, "\n Validation Data Shape", X_val.shape, "\n Validation Feature Data Shape",Y_val.shape, "\n Testing Data Shape",X_test.shape, "Testing Data Shape",Y_test.shape)

# Normalize the pixel values
X_train = X_train.astype('float32') / 255.0
X_test = X_test.astype('float32') / 255.0
X_val = X_val.astype('float32') / 255.0

# One-hot encode the labels
num_classes = 100
Y_train = to_categorical(Y_train, num_classes)
Y_test = to_categorical(Y_test, num_classes)
Y_val = to_categorical(Y_val, num_classes)

# Flatten the labels to a 1D array
Y_train = np.argmax(Y_train, axis=1)
Y_test = np.argmax(Y_test, axis=1)
Y_val = np.argmax(Y_val, axis=1)



# With Just Batch Normalization and L2 Regularization
model = Sequential()

model.add(Conv2D(input_shape=(32, 32, 3),kernel_size=(2, 2),padding="same",strides=(2, 2),filters=32,kernel_regularizer=l2(0.001)))#,kernel_regularizer=l2(0.001)
model.add(BatchNormalization())
model.add(Activation("relu"))
model.add(MaxPooling2D(pool_size=(2, 2), strides=(1, 1), padding="same"))
# model.add(Dropout(0.1))

model.add(Conv2D(kernel_size=(2, 2), padding="same", strides=(2, 2), filters=64))
model.add(BatchNormalization())
model.add(Activation("relu"))
model.add(MaxPooling2D(pool_size=(2, 2), strides=(1, 1), padding="same"))

model.add(Conv2D(kernel_size=(2, 2), padding="same", strides=(2, 2), filters=128))
model.add(BatchNormalization())
model.add(Activation("relu"))
model.add(MaxPooling2D(pool_size=(2, 2), strides=(1, 1), padding="same"))


model.add(Conv2D(kernel_size=(2, 2), padding="same", strides=(2, 2), filters=256))
model.add(BatchNormalization())
model.add(Activation("relu"))
model.add(MaxPooling2D(pool_size=(2, 2), strides=(1, 1), padding="same"))
# model.add(Dropout(0.1))

model.add(Conv2D(kernel_size=(2, 2), padding="same", strides=(2, 2), filters=512))
model.add(BatchNormalization())
model.add(Activation("relu"))
model.add(MaxPooling2D(pool_size=(2, 2), strides=(1, 1), padding="same"))

model.add(Conv2D(kernel_size=(2, 2), padding="same", strides=(2, 2), filters=1024))
model.add(BatchNormalization())
model.add(Activation("relu"))
model.add(MaxPooling2D(pool_size=(2, 2), strides=(1, 1), padding="same"))

model.add(Flatten())
model.add(Dense(256))
model.add(BatchNormalization())
model.add(Activation("relu"))

model.add(Dense(128))
model.add(BatchNormalization())
model.add(Activation("relu"))

model.add(Dense(100, activation="softmax"))


# Define early stopping criteria
early_stop = EarlyStopping(monitor='val_loss', patience=5)

model.summary()

opt = 'Adam'
model.compile(loss='sparse_categorical_crossentropy',
             optimizer = opt,
             metrics=['accuracy'])

# # Viusalize the model
# model = visualkeras.layered_view(model).show()
# visualkeras.layered_view(model, legend="True", to_file='output.png') 
# visualkeras.layered_view(model, to_file='output.png').show()

# Fit the model on the data
model.fit(X_train, Y_train, epochs=50, validation_data=(X_val, Y_val), callbacks=[early_stop])

# Model testing
test_loss,test_acc = model.evaluate(X_test, Y_test)
print("test accuracy", test_acc)


# CONFUSION MATRIX
def plot_confusion_matrix(cm, classes,normalize= True,
                         title='Confusion matrix', cmap = plt.cm.Reds):
    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()
    
    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        plt.tight_layout()
        plt.ylabel('Observation')
        plt.xlabel('Prediction')

Y_pred = model.predict(X_test)
# Convert predictions classes to one hot encoders
Y_pred_classes = np.argmax(Y_pred, axis = 1)
confusion_mtx = confusion_matrix(Y_test, Y_pred_classes)

# Plot the confusion matrix
plot_confusion_matrix(confusion_mtx, classes = range(100))
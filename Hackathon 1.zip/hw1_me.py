'''
Specify a simple optimization problem that you will solve with gradient descent (as above). Then, play around with the learning rate and number of update iterations to get an intuitive understanding of how they affect your solver. Write up a paragraph describing your equation, how learning rate and number of iterations gave a better or worse solution, and with your intuition for why.
'''
# We'll start with our library imports...
# from __future__ import print_function

import numpy as np  # to use numpy arrays
import tensorflow as tf  # to specify and run computation graphs

learning_rate = 0.25
num_iterations = 20

# Define the optimization problem as a polynomial equation: Ax^2 + Bx + C = 5
A = tf.Variable(3.0, dtype=tf.float32)
B = tf.Variable(2.0, dtype=tf.float32)
C = tf.Variable(1.0, dtype=tf.float32)

# Define the target value
target = 5.0

# Define the optimizer
optimizer = tf.optimizers.Adam(learning_rate=0.01)

# Define the number of iterations
num_iterations = 50

# Optimize the variables using the Adam Optimizer
for step in range(num_iterations):
    with tf.GradientTape() as tape:
        # Calculate the equation: Ax^2 + Bx + C = 5
        equation = A * x**2 + B * x + C
        # Calculate the loss value we want to minimize
        loss = tf.math.square(equation - target)
        # Calculate the gradient
        grads = tape.gradient(loss, [A, B, C])
    # Update the variables
    optimizer.apply_gradients(zip(grads, [A, B, C]))

# Print the final values of A, B, and C
print("A:", A.numpy())
print("B:", B.numpy())
print("C:", C.numpy())

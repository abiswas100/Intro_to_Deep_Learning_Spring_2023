import tensorflow as tf
import numpy as np 

learning_rate = 0.25
num_iterations = 1

optimizer = tf.keras.optimizers.Adam(learning_rate)

x = tf.Variable(tf.ones([1, 1]))
y = tf.Variable(tf.ones([1, 1]))

for step in range(num_iterations):
    with tf.GradientTape() as tape:
        area = x * y
        perimeter = 2 * x + 2 * y
        difference_sq = tf.math.square(perimeter - 100)
        gradients = tape.gradient(difference_sq, [x, y])
        optimizer.apply_gradients(zip(gradients, [x, y]))
        
        print("Iteration", step)
        print("x:", x.numpy())
        print("y:", y.numpy())
        print("Area:", area.numpy())
        print("Perimeter:", perimeter.numpy())
        print("Squared error:", tf.norm(tf.math.sqrt(difference_sq)).numpy())
        print()

maximum_area = x * y
print("With 100 ft of wire fencing, the maximum area of the garden is", maximum_area.numpy()[0][0], "square feet.")

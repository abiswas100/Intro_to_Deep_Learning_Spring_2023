# We'll start with our library imports...
# from __future__ import print_function

import numpy as np  # to use numpy arrays
import tensorflow as tf  # to specify and run computation graphs


learning_rate = 0.25
num_iterations = 10

# the optimizer allows us to apply gradients to update variables
optimizer = tf.keras.optimizers.Adam(learning_rate)

# Create a variable x
x = tf.Variable(tf.ones([1]))

# Check the initial value
print("Initial x:", x.numpy())
print("f(x):", x**3 + x**2)
print()

# We want to minimize f(x) = x^2, so we'll try to minimize its value
for step in range(num_iterations):
    print("Iteration", step)
    with tf.GradientTape() as tape:
        # Calculate f(x)
        cost = x**2 + x**3
        print("f(x):", cost.numpy())
        # calculate the gradient
        grad = tape.gradient(cost, [x])
        print("Gradients:")
        print(grad)
        # update x
        optimizer.apply_gradients(zip(grad, [x]))
        print()

# Check the final value
print("Optimized x", x.numpy())

import os
import matplotlib.pyplot as plt  # to visualize data and draw plots
import numpy as np  # to use numpy arrays
import tensorflow as tf  # to specify and run computation graphs

from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split, KFold

from tensorflow.keras.layers import *
from tensorflow.keras.models import Model, Sequential
from tensorflow.keras.layers import Dense, Dropout, Embedding, LSTM, Bidirectional, Activation
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.regularizers import l1, l2
from tensorflow.keras import regularizers
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.preprocessing import sequence

from tensorflow.keras.datasets import imdb 
from tensorflow.keras import backend as K

#import seaborn as sns
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"

# Import the data
n_unique_words = 20000
(x_train, y_train),(x_test, y_test) = imdb.load_data(num_words=n_unique_words)

# Pad the sequences
maxlen = 200
x_train = sequence.pad_sequences(x_train, maxlen=maxlen)
x_test = sequence.pad_sequences(x_test, maxlen=maxlen)
y_train = np.array(y_train)
y_test = np.array(y_test)

# create a custom attention layer class
class attention(Layer):
    def __init__(self, return_sequences=True):
        self.return_sequences = return_sequences

        super(attention,self).__init__()

    def build(self, input_shape):
        self.W=self.add_weight(name="att_weight", shape=(input_shape[-1],1),initializer="normal")
        self.b= self.add_weight(name="att_bias", shape=(input_shape[1],1),initializer="normal")
        self.b= self.add_weight(name="att_bias", shape=(input_shape[1],1))
        # self.b= self.add_weight(name="att_bias", shape=(input_shape[1],1), 

        super(attention,self).build(input_shape)


    def call(self, x):
        e = K.tanh(K.dot(x,self.W)+self.b)
        a = K.softmax(e, axis=1)
        output = x*a
        if self.return_sequences:

            return output
        return K.sum(output, axis=1)

# Define the model
model = Sequential()
model.add(Embedding(n_unique_words, 128, input_length=maxlen))
model.add(Bidirectional(LSTM(128, return_sequences=True)))
model.add(Bidirectional(LSTM(64, return_sequences=True)))
model.add(attention(return_sequences=False)) # receive 3D and output 3D
model.add(Dropout(0.5))
model.add(Dense(16, activation='sigmoid'))
model.add(Dense(1, activation='sigmoid'))

#Compile the Layer
model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy']) 
model.summary()

# Define early stopping to prevent overfitting
early_stop = EarlyStopping(monitor='val_loss', mode='min', verbose=1, patience=5)
# Define the nuuber of folds for K-fold cross-validation
num_folds = 10
# Define the K-fold cross-validator
kfold = KFold(n_splits=num_folds, shuffle=True)
# Define a list to store the model's performance on each fold
fold_scores = []

'''
Train the Model over each fold
'''
# Loop over each fold
for fold, (train_indices, val_indices) in enumerate(kfold.split(x_train)):
    print('Fold', fold+1)

    # Split the data into training and validation sets for this fold
    fold_x_train, fold_y_train = x_train[train_indices], y_train[train_indices]
    fold_x_val, fold_y_val = x_train[val_indices], y_train[val_indices]

    # Train the model on this fold's training data
    model.fit(fold_x_train, fold_y_train, batch_size=32, epochs=10, validation_data=(fold_x_val, fold_y_val), callbacks=[early_stop])

    # Evaluate the model on this fold's validation data
    fold_score = model.evaluate(fold_x_val, fold_y_val, verbose=0)
    print('Validation loss:', fold_score[0])
    print('Validation accuracy:', fold_score[1])

    # Add this fold's score to the list of fold scores
    fold_scores.append(fold_score[1])
    
    
    
# Testing model on test data
loss, accuracy = model.evaluate(x_test, y_test)
print('Test Loss:', loss)
print('Test Accuracy:', accuracy)

# Get Y_prediction
Y_pred = model.predict(x_test)
Y_pred = Y_pred.ravel() 
y_pred_binary = np.where(Y_pred >= 0.5, 1, 0)

conf_matrix = confusion_matrix(y_test, y_pred_binary)
tn, fp, fn, tp = conf_matrix.ravel()

sns.set(font_scale=1.4)
sns.heatmap(conf_matrix, annot=True, fmt='g', cmap='Blues', 
            xticklabels=['Negative', 'Positive'], yticklabels=['Negative', 'Positive'])
plt.xlabel('Predicted Labels')
plt.ylabel('True Labels')
plt.title(f'Confusion Matrix\nTrue Positives: {tp}\nTrue Negatives: {tn}\nFalse Positives: {fp}\nFalse Negatives: {fn}')
plt.savefig('confusion_matrix.png', dpi=300, bbox_inches='tight')
plt.show()